<#
  Создаёт проект my-ai-app (Vite + React + JS) без диалогов.
  Требования: Node.js, npm/npx в PATH. Админ-права не нужны.
#>

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# 1. Название проекта и путь
$ProjectName = 'my-ai-app'
$Desktop     = [Environment]::GetFolderPath('Desktop')   # надёжно на любой локали :contentReference[oaicite:1]{index=1}
Set-Location $Desktop

# 2. Основная попытка — quoted '--'
try {
    Write-Host '▶ Пытаюсь с аргументом ''--'' …'
    npx --yes create-vite@latest $ProjectName '--' --template react   # PowerShell-совместимо :contentReference[oaicite:2]{index=2}
    $Succeeded = $true
} catch {
    $Succeeded = $false
}

# 3. Резерв — «тройное» тире (Windows npm 10+ workaround)
if (-not $Succeeded) {
    Write-Host '▶ Первый способ не сработал, пробую с --- …'
    npx --yes create-vite@latest $ProjectName --- --template react    # workaround для npm/PowerShell :contentReference[oaicite:3]{index=3}
}

# 4. Устанавливаем зависимости (последние версии npm уже делает это, но дублируем для надёжности)
Set-Location "$Desktop\$ProjectName"
npm install --loglevel=error   # тихая установка пакетов :contentReference[oaicite:4]{index=4}

Write-Host "`n✔ Проект $ProjectName готов! Запустите 'npm run dev'."
